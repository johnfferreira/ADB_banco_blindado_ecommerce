--
-- PostgreSQL database dump
--

\restrict n8Y1wxtvwGE29CaV0U5B66Hy54HU6fddK5fhalmDl92Q3XydyX18IPSesbgmwJ0

-- Dumped from database version 16.14 (Debian 16.14-1.pgdg13+1)
-- Dumped by pg_dump version 16.14 (Debian 16.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categorias; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categorias (
    id integer NOT NULL,
    nome character varying(80) NOT NULL
);


ALTER TABLE public.categorias OWNER TO postgres;

--
-- Name: categorias_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categorias_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categorias_id_seq OWNER TO postgres;

--
-- Name: categorias_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categorias_id_seq OWNED BY public.categorias.id;


--
-- Name: clientes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clientes (
    id integer NOT NULL,
    nome character varying(100) NOT NULL,
    email character varying(150) NOT NULL,
    telefone character varying(20),
    senha_hash text,
    criado_em timestamp without time zone DEFAULT now()
);


ALTER TABLE public.clientes OWNER TO postgres;

--
-- Name: clientes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.clientes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.clientes_id_seq OWNER TO postgres;

--
-- Name: clientes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.clientes_id_seq OWNED BY public.clientes.id;


--
-- Name: itens_pedido; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.itens_pedido (
    id integer NOT NULL,
    pedido_id integer NOT NULL,
    produto_id integer NOT NULL,
    quantidade integer NOT NULL,
    preco_unitario numeric(10,2) NOT NULL,
    CONSTRAINT itens_pedido_quantidade_check CHECK ((quantidade > 0))
);


ALTER TABLE public.itens_pedido OWNER TO postgres;

--
-- Name: itens_pedido_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.itens_pedido_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.itens_pedido_id_seq OWNER TO postgres;

--
-- Name: itens_pedido_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.itens_pedido_id_seq OWNED BY public.itens_pedido.id;


--
-- Name: pedidos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pedidos (
    id integer NOT NULL,
    cliente_id integer NOT NULL,
    status character varying(20) DEFAULT 'pendente'::character varying,
    total numeric(12,2),
    criado_em timestamp without time zone DEFAULT now(),
    CONSTRAINT pedidos_status_check CHECK (((status)::text = ANY ((ARRAY['pendente'::character varying, 'pago'::character varying, 'cancelado'::character varying])::text[])))
);


ALTER TABLE public.pedidos OWNER TO postgres;

--
-- Name: pedidos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pedidos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pedidos_id_seq OWNER TO postgres;

--
-- Name: pedidos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pedidos_id_seq OWNED BY public.pedidos.id;


--
-- Name: produtos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.produtos (
    id integer NOT NULL,
    nome character varying(150) NOT NULL,
    preco numeric(10,2) NOT NULL,
    stock integer DEFAULT 0 NOT NULL,
    categoria_id integer,
    criado_em timestamp without time zone DEFAULT now(),
    CONSTRAINT produtos_preco_check CHECK ((preco > (0)::numeric))
);


ALTER TABLE public.produtos OWNER TO postgres;

--
-- Name: produtos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.produtos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.produtos_id_seq OWNER TO postgres;

--
-- Name: produtos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.produtos_id_seq OWNED BY public.produtos.id;


--
-- Name: utilizadores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.utilizadores (
    id integer NOT NULL,
    nome character varying(100) NOT NULL,
    email character varying(150) NOT NULL,
    senha_hash text NOT NULL,
    papel character varying(20) DEFAULT 'estagiario'::character varying NOT NULL,
    criado_em timestamp without time zone DEFAULT now(),
    CONSTRAINT utilizadores_papel_check CHECK (((papel)::text = ANY ((ARRAY['estagiario'::character varying, 'gerente'::character varying, 'sistema'::character varying])::text[])))
);


ALTER TABLE public.utilizadores OWNER TO postgres;

--
-- Name: utilizadores_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.utilizadores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.utilizadores_id_seq OWNER TO postgres;

--
-- Name: utilizadores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.utilizadores_id_seq OWNED BY public.utilizadores.id;


--
-- Name: categorias id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categorias ALTER COLUMN id SET DEFAULT nextval('public.categorias_id_seq'::regclass);


--
-- Name: clientes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clientes ALTER COLUMN id SET DEFAULT nextval('public.clientes_id_seq'::regclass);


--
-- Name: itens_pedido id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itens_pedido ALTER COLUMN id SET DEFAULT nextval('public.itens_pedido_id_seq'::regclass);


--
-- Name: pedidos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedidos ALTER COLUMN id SET DEFAULT nextval('public.pedidos_id_seq'::regclass);


--
-- Name: produtos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produtos ALTER COLUMN id SET DEFAULT nextval('public.produtos_id_seq'::regclass);


--
-- Name: utilizadores id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.utilizadores ALTER COLUMN id SET DEFAULT nextval('public.utilizadores_id_seq'::regclass);


--
-- Data for Name: categorias; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categorias (id, nome) FROM stdin;
1	Electrónica
2	Roupas
3	Alimentação
4	Informática
5	Electrodomésticos
\.


--
-- Data for Name: clientes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clientes (id, nome, email, telefone, senha_hash, criado_em) FROM stdin;
1	João Silva	joao@email.com	+244 923 000 001	$2a$06$BhJ4XOH55Lgn/KkMDKm54ujhXZofpS1of6VdwZYWuqRGK7m.RwGau	2026-06-04 12:07:56.162548
2	Maria Costa	maria@email.com	+244 923 000 002	$2a$06$xpKWUki8eO71guYWrKGI9OvQd8/FqnryAb6UTyR1P3zEQd2BkJYua	2026-06-04 12:07:56.162548
3	Pedro Lopes	pedro@email.com	+244 923 000 003	$2a$06$Dh9wJN3PgGlZkUe5KMlSFO337z7RcOTcZuJWdRG4UcGRCsDCIamEK	2026-06-04 12:07:56.162548
4	Ana Ferreira	ana@email.com	+244 923 000 004	$2a$06$fFuEW/hxFq2VI5haWEqZVOIXh72DC0jKefY18xHMDBFSn1v8YvqTe	2026-06-04 12:07:56.162548
5	Carlos Matos	carlos@email.com	+244 923 000 005	$2a$06$NpraGu6eZa7IJnZke237Yu7nizbCM6fefbIqvPKnBaOgNufIpneMe	2026-06-04 12:07:56.162548
\.


--
-- Data for Name: itens_pedido; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.itens_pedido (id, pedido_id, produto_id, quantidade, preco_unitario) FROM stdin;
1	1	1	1	45000.00
2	1	2	1	8500.00
3	2	4	1	5500.00
4	3	7	1	150000.00
5	3	8	1	4500.00
6	4	2	1	8500.00
7	5	3	1	3200.00
8	5	5	1	1800.00
\.


--
-- Data for Name: pedidos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pedidos (id, cliente_id, status, total, criado_em) FROM stdin;
1	1	pago	53500.00	2026-06-04 12:07:56.192354
2	2	pago	5500.00	2026-06-04 12:07:56.192354
3	3	pendente	154500.00	2026-06-04 12:07:56.192354
4	1	cancelado	8500.00	2026-06-04 12:07:56.192354
5	4	pago	5000.00	2026-06-04 12:07:56.192354
\.


--
-- Data for Name: produtos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.produtos (id, nome, preco, stock, categoria_id, criado_em) FROM stdin;
1	Smartphone Samsung A15	45000.00	30	1	2026-06-04 12:07:56.187586
2	Auriculares Bluetooth	8500.00	50	1	2026-06-04 12:07:56.187586
3	Camisa Social Branca	3200.00	100	2	2026-06-04 12:07:56.187586
4	Calças Jeans	5500.00	80	2	2026-06-04 12:07:56.187586
5	Arroz 5kg	1800.00	200	3	2026-06-04 12:07:56.187586
6	Azeite 1L	2400.00	150	3	2026-06-04 12:07:56.187586
7	Laptop Lenovo	150000.00	15	4	2026-06-04 12:07:56.187586
8	Rato sem fio	4500.00	60	4	2026-06-04 12:07:56.187586
9	Frigorífico 300L	120000.00	10	5	2026-06-04 12:07:56.187586
10	Microondas 20L	35000.00	25	5	2026-06-04 12:07:56.187586
\.


--
-- Data for Name: utilizadores; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.utilizadores (id, nome, email, senha_hash, papel, criado_em) FROM stdin;
1	Carlos Estagiário	carlos@ecommerce.ao	$2a$06$1V1uFxVVRqYDLGTxpeXgVOXGHZB6LQClti2hT9aGaxbkq2KXZ/SgW	estagiario	2026-06-04 12:07:56.140565
2	Ana Gerente	ana@ecommerce.ao	$2a$06$US2/nJcSn2KBen7FsDY25uc7v.dx6DA1YmCJELZrJyyKvSZ5om09u	gerente	2026-06-04 12:07:56.140565
3	App Backend	app@ecommerce.ao	$2a$06$3M.1/CXq/7oaNE4zyRND3OCIhfTqeCs4B28fPyjh3bJHltw7PVrmy	sistema	2026-06-04 12:07:56.140565
\.


--
-- Name: categorias_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categorias_id_seq', 5, true);


--
-- Name: clientes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.clientes_id_seq', 5, true);


--
-- Name: itens_pedido_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.itens_pedido_id_seq', 8, true);


--
-- Name: pedidos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pedidos_id_seq', 5, true);


--
-- Name: produtos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.produtos_id_seq', 10, true);


--
-- Name: utilizadores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.utilizadores_id_seq', 3, true);


--
-- Name: categorias categorias_nome_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categorias
    ADD CONSTRAINT categorias_nome_key UNIQUE (nome);


--
-- Name: categorias categorias_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categorias
    ADD CONSTRAINT categorias_pkey PRIMARY KEY (id);


--
-- Name: clientes clientes_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_email_key UNIQUE (email);


--
-- Name: clientes clientes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_pkey PRIMARY KEY (id);


--
-- Name: itens_pedido itens_pedido_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itens_pedido
    ADD CONSTRAINT itens_pedido_pkey PRIMARY KEY (id);


--
-- Name: pedidos pedidos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedidos
    ADD CONSTRAINT pedidos_pkey PRIMARY KEY (id);


--
-- Name: produtos produtos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produtos
    ADD CONSTRAINT produtos_pkey PRIMARY KEY (id);


--
-- Name: utilizadores utilizadores_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.utilizadores
    ADD CONSTRAINT utilizadores_email_key UNIQUE (email);


--
-- Name: utilizadores utilizadores_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.utilizadores
    ADD CONSTRAINT utilizadores_pkey PRIMARY KEY (id);


--
-- Name: idx_pedidos_cliente_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pedidos_cliente_id ON public.pedidos USING btree (cliente_id);


--
-- Name: idx_pedidos_criado_em; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pedidos_criado_em ON public.pedidos USING btree (criado_em);


--
-- Name: idx_produtos_categoria_preco; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_produtos_categoria_preco ON public.produtos USING btree (categoria_id, preco);


--
-- Name: itens_pedido itens_pedido_pedido_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itens_pedido
    ADD CONSTRAINT itens_pedido_pedido_id_fkey FOREIGN KEY (pedido_id) REFERENCES public.pedidos(id);


--
-- Name: itens_pedido itens_pedido_produto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itens_pedido
    ADD CONSTRAINT itens_pedido_produto_id_fkey FOREIGN KEY (produto_id) REFERENCES public.produtos(id);


--
-- Name: pedidos pedidos_cliente_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedidos
    ADD CONSTRAINT pedidos_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES public.clientes(id);


--
-- Name: produtos produtos_categoria_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produtos
    ADD CONSTRAINT produtos_categoria_id_fkey FOREIGN KEY (categoria_id) REFERENCES public.categorias(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO role_estagiario;
GRANT USAGE ON SCHEMA public TO role_sistema;
GRANT USAGE ON SCHEMA public TO role_gerente;


--
-- Name: TABLE categorias; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.categorias TO role_estagiario;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.categorias TO role_gerente;


--
-- Name: SEQUENCE categorias_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.categorias_id_seq TO role_sistema;


--
-- Name: TABLE clientes; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.clientes TO role_estagiario;
GRANT INSERT ON TABLE public.clientes TO role_sistema;
GRANT SELECT,INSERT,UPDATE ON TABLE public.clientes TO role_gerente;


--
-- Name: SEQUENCE clientes_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.clientes_id_seq TO role_sistema;


--
-- Name: TABLE itens_pedido; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.itens_pedido TO role_estagiario;
GRANT INSERT ON TABLE public.itens_pedido TO role_sistema;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.itens_pedido TO role_gerente;


--
-- Name: SEQUENCE itens_pedido_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.itens_pedido_id_seq TO role_sistema;


--
-- Name: TABLE pedidos; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.pedidos TO role_estagiario;
GRANT INSERT ON TABLE public.pedidos TO role_sistema;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.pedidos TO role_gerente;


--
-- Name: SEQUENCE pedidos_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.pedidos_id_seq TO role_sistema;


--
-- Name: TABLE produtos; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.produtos TO role_estagiario;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.produtos TO role_gerente;


--
-- Name: SEQUENCE produtos_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.produtos_id_seq TO role_sistema;


--
-- Name: TABLE utilizadores; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.utilizadores TO role_estagiario;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.utilizadores TO role_gerente;


--
-- Name: SEQUENCE utilizadores_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.utilizadores_id_seq TO role_sistema;


--
-- PostgreSQL database dump complete
--

\unrestrict n8Y1wxtvwGE29CaV0U5B66Hy54HU6fddK5fhalmDl92Q3XydyX18IPSesbgmwJ0

